import React, { useState } from 'react';
import { Search, Filter } from 'lucide-react';
import { Link } from 'react-router-dom';

interface Article {
  id: number;
  type: 'blog' | 'case-study' | 'thought-leadership';
  title: string;
  description: string;
  content: string;
  date: string;
  image: string;
  category: string;
  tags?: string[];
}

export const articles: Article[] = [
  {
    id: 1,
    type: 'blog',
    title: 'The Future of Personalized Medicine',
    description: 'Exploring how AI and genomics are revolutionizing healthcare delivery and treatment approaches.',
    content: `<h2>The Future of Personalized Medicine</h2>
    <p>Personalized medicine, also known as precision medicine, is revolutionizing healthcare by tailoring medical treatment to the individual characteristics of each patient. This approach takes into account genetic makeup, environmental factors, and lifestyle choices to create targeted therapeutic strategies.</p>
    <h3>The Role of AI and Machine Learning</h3>
    <p>Artificial Intelligence and Machine Learning are playing crucial roles in advancing personalized medicine by:</p>
    <ul>
      <li>Analyzing vast amounts of patient data</li>
      <li>Identifying patterns in genetic information</li>
      <li>Predicting treatment outcomes</li>
      <li>Recommending personalized treatment plans</li>
    </ul>`,
    date: '2025-03-15',
    image: 'https://images.pexels.com/photos/2280571/pexels-photo-2280571.jpeg',
    category: 'Technology',
    tags: ['AI', 'Healthcare', 'Innovation', 'Gene Therapy', 'Strategic Planning']
  },
  {
    id: 2,
    type: 'case-study',
    title: 'Digital Transformation in Biotech Manufacturing',
    description: 'How a leading biotech company achieved 40% efficiency improvement through digital adoption.',
    content: `<h2>Digital Transformation in Biotech Manufacturing</h2>
    <p>This case study examines how a leading biotech manufacturer implemented digital solutions to transform their operations and achieve significant efficiency improvements.</p>
    <h3>Challenge</h3>
    <p>The company faced increasing competition and pressure to reduce costs while maintaining quality standards.</p>
    <h3>Solution</h3>
    <p>Implementation of:</p>
    <ul>
      <li>IoT sensors for real-time monitoring</li>
      <li>AI-powered predictive maintenance</li>
      <li>Digital twin technology</li>
    </ul>`,
    date: '2025-03-10',
    image: 'https://images.pexels.com/photos/2280547/pexels-photo-2280547.jpeg',
    category: 'Operations',
    tags: ['Digital Transformation', 'Manufacturing', 'Efficiency', 'Technology', 'Innovation']
  },
  {
    id: 3,
    type: 'thought-leadership',
    title: 'Navigating Regulatory Changes in Biopharma',
    description: 'Key strategies for maintaining compliance while driving innovation in a changing regulatory landscape.',
    content: `<h2>Navigating Regulatory Changes in Biopharma</h2>
    <p>The biopharmaceutical industry faces constant regulatory evolution. This article explores strategies for maintaining compliance while fostering innovation.</p>
    <h3>Key Considerations</h3>
    <ul>
      <li>Understanding regulatory trends</li>
      <li>Building flexible compliance frameworks</li>
      <li>Leveraging technology for compliance</li>
    </ul>`,
    date: '2025-03-05',
    image: 'https://images.pexels.com/photos/3683074/pexels-photo-3683074.jpeg',
    category: 'Regulatory',
    tags: ['Regulatory', 'Compliance', 'Innovation', 'Strategy', 'Risk Management']
  }
];

const Insights = () => {
  const [selectedType, setSelectedType] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filteredArticles = articles.filter(article => {
    const matchesType = selectedType === 'all' || article.type === selectedType;
    const matchesSearch = article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         article.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesType && matchesSearch;
  });

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-primary-900 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl font-display font-bold sm:text-5xl">Insights</h1>
            <p className="mt-6 text-xl text-primary-100 max-w-3xl mx-auto">
              Expert perspectives, industry trends, and success stories from the frontlines of life sciences consulting.
            </p>
          </div>
        </div>
      </section>

      {/* Filters and Search */}
      <section className="bg-white py-8 border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="flex items-center space-x-4">
              <Filter className="h-5 w-5 text-secondary-500" />
              <select
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
                className="rounded-md border-secondary-300 py-2 pl-3 pr-10 text-base focus:border-primary-500 focus:outline-none focus:ring-primary-500"
              >
                <option value="all">All Content</option>
                <option value="blog">Blog Posts</option>
                <option value="case-study">Case Studies</option>
                <option value="thought-leadership">Thought Leadership</option>
              </select>
            </div>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-secondary-400" />
              <input
                type="text"
                placeholder="Search insights..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-4 py-2 border border-secondary-300 rounded-md w-full md:w-64 focus:border-primary-500 focus:ring-primary-500"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Articles Grid */}
      <section className="py-12 bg-secondary-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredArticles.map((article) => (
              <Link
                to={`/insights/${article.id}`}
                key={article.id}
                className="bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-md transition-shadow duration-300"
              >
                <img
                  src={article.image}
                  alt={article.title}
                  className="h-48 w-full object-cover"
                />
                <div className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-sm font-medium text-primary-600 capitalize">
                      {article.type.replace('-', ' ')}
                    </span>
                    <span className="text-sm text-secondary-500">
                      {new Date(article.date).toLocaleDateString('en-US', {
                        month: 'long',
                        day: 'numeric',
                        year: 'numeric'
                      })}
                    </span>
                  </div>
                  <h3 className="text-xl font-semibold text-secondary-900 mb-2">
                    {article.title}
                  </h3>
                  <p className="text-secondary-600">
                    {article.description}
                  </p>
                  <div className="mt-4">
                    <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-secondary-100 text-secondary-800">
                      {article.category}
                    </span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Insights;