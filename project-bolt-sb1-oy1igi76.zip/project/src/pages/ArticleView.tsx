import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { articles } from './Insights';

const ArticleView = () => {
  const { id } = useParams();
  const article = articles.find(a => a.id === Number(id));

  if (!article) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center">
          <h1 className="text-4xl font-display font-bold text-secondary-900">Article not found</h1>
          <Link to="/insights" className="mt-8 inline-flex items-center text-primary-600 hover:text-primary-700">
            <ArrowLeft className="mr-2 h-5 w-5" />
            Back to Insights
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="bg-primary-900 text-white py-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Link to="/insights" className="inline-flex items-center text-primary-100 hover:text-white">
            <ArrowLeft className="mr-2 h-5 w-5" />
            Back to Insights
          </Link>
          <h1 className="mt-6 text-4xl font-display font-bold">{article.title}</h1>
          <div className="mt-6 flex items-center justify-between">
            <span className="text-primary-100">{article.category}</span>
            <span className="text-primary-100">
              {new Date(article.date).toLocaleDateString('en-US', {
                month: 'long',
                day: 'numeric',
                year: 'numeric',
              })}
            </span>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <img
          src={article.image}
          alt={article.title}
          className="w-full h-96 object-cover rounded-xl mb-12"
        />
        <div className="prose max-w-none" dangerouslySetInnerHTML={{ __html: article.content }} />
      </div>
    </div>
  );
};

export default ArticleView;