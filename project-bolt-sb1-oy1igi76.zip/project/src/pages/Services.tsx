import React, { useState } from 'react';
import { LineChart, HeartHandshake as Handshake, FileSearch, Building2, Brain, ShieldCheck } from 'lucide-react';
import ServiceModal from '../components/ServiceModal';

interface ServiceData {
  title: string;
  description: string;
  bulletPoints: string[];
  caseStudies: {
    title: string;
    description: string;
    tags: string[];
  }[];
}

const serviceData: Record<string, ServiceData> = {
  'Market Intelligence': {
    title: 'Market Intelligence and Strategy',
    description: 'Comprehensive market analysis and strategic planning services to help life sciences companies make informed decisions and achieve sustainable growth.',
    bulletPoints: [
      'Competitive landscape analysis',
      'Market sizing and forecasting',
      'Strategic planning and implementation',
      'Portfolio optimization',
      'Commercial opportunity assessment'
    ],
    caseStudies: [
      {
        title: 'Market Entry Strategy for Novel Gene Therapy',
        description: 'Helped a biotech company successfully enter the gene therapy market with a comprehensive analysis and strategic roadmap.',
        tags: ['Market Entry', 'Gene Therapy', 'Strategic Planning']
      },
      {
        title: 'Portfolio Prioritization for Top 10 Pharma',
        description: 'Assisted a leading pharmaceutical company in optimizing their product portfolio through data-driven analysis.',
        tags: ['Portfolio Strategy', 'Market Analysis', 'Commercial Assessment']
      }
    ]
  },
  'Custom Intelligence': {
    title: 'Custom Intelligence Solutions',
    description: 'Tailored research and analysis services to provide deep insights into specific therapeutic areas, technologies, or market segments.',
    bulletPoints: [
      'Primary and secondary market research',
      'Technology landscape analysis',
      'KOL engagement and insights',
      'Competitive intelligence',
      'Market opportunity assessment'
    ],
    caseStudies: [
      {
        title: 'Oncology Market Deep Dive',
        description: 'Conducted comprehensive analysis of the immuno-oncology landscape for strategic decision-making.',
        tags: ['Oncology', 'Market Research', 'Competitive Intelligence']
      },
      {
        title: 'KOL Insight Generation',
        description: 'Gathered and synthesized expert opinions to inform clinical development strategy.',
        tags: ['KOL Engagement', 'Clinical Strategy', 'Expert Insights']
      }
    ]
  },
  'Due Diligence': {
    title: 'Due Diligence Services',
    description: 'Comprehensive evaluation services for assets, technologies, and potential partnerships to support strategic decision-making.',
    bulletPoints: [
      'Technical assessment',
      'Commercial potential evaluation',
      'Risk assessment',
      'Regulatory review',
      'Market opportunity validation'
    ],
    caseStudies: [
      {
        title: 'Pre-acquisition Technical Due Diligence',
        description: 'Conducted thorough technical assessment of a novel platform technology for a potential acquisition.',
        tags: ['Technical Assessment', 'M&A', 'Technology Evaluation']
      },
      {
        title: 'Commercial Due Diligence for Licensing Deal',
        description: 'Evaluated market potential and commercial viability of a late-stage asset.',
        tags: ['Commercial Assessment', 'Licensing', 'Market Analysis']
      }
    ]
  },
  'M&A': {
    title: 'Mergers & Acquisitions',
    description: 'End-to-end M&A advisory services for life sciences companies, from target identification to post-merger integration.',
    bulletPoints: [
      'Deal strategy and target identification',
      'Valuation and financial modeling',
      'Due diligence coordination',
      'Transaction structuring',
      'Post-merger integration planning'
    ],
    caseStudies: [
      {
        title: 'Cross-border Biotech Acquisition',
        description: 'Advised on successful acquisition of an European biotech company by a US pharmaceutical company.',
        tags: ['M&A', 'Cross-border', 'Transaction Advisory']
      },
      {
        title: 'Strategic Merger of Equals',
        description: 'Supported the merger of two mid-sized biotechnology companies to create a leader in rare diseases.',
        tags: ['Merger', 'Integration', 'Strategy']
      }
    ]
  },
  'Licensing': {
    title: 'Licensing and Business Development',
    description: 'Comprehensive licensing and BD services to support strategic growth through partnerships and collaborations.',
    bulletPoints: [
      'Opportunity identification',
      'Partner search and evaluation',
      'Deal structuring and negotiation',
      'Alliance management setup',
      'Strategic planning'
    ],
    caseStudies: [
      {
        title: 'Global Licensing Deal',
        description: 'Facilitated a major licensing agreement between a biotech and global pharmaceutical company.',
        tags: ['Licensing', 'Deal Structure', 'Negotiation']
      },
      {
        title: 'Academic Partnership Program',
        description: 'Developed and implemented a systematic approach to academic partnerships.',
        tags: ['Academic Collaboration', 'Partnership', 'Strategy']
      }
    ]
  },
  'Partnership': {
    title: 'Strategic Partnerships',
    description: 'Expert guidance in establishing and managing strategic partnerships to accelerate growth and innovation.',
    bulletPoints: [
      'Partnership strategy development',
      'Partner identification and evaluation',
      'Alliance management',
      'Collaboration framework design',
      'Performance monitoring'
    ],
    caseStudies: [
      {
        title: 'Strategic Research Collaboration',
        description: 'Established a multi-year research collaboration between pharma and academic institutions.',
        tags: ['Research Collaboration', 'Academic Partnership', 'Alliance Management']
      },
      {
        title: 'Co-development Partnership',
        description: 'Structured and implemented a co-development agreement for a novel therapeutic.',
        tags: ['Co-development', 'Partnership', 'Deal Structure']
      }
    ]
  }
};

const Services = () => {
  const [selectedService, setSelectedService] = useState<string | null>(null);

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-primary-900 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl font-display font-bold sm:text-5xl">Our Services</h1>
            <p className="mt-6 text-xl text-primary-100 max-w-3xl mx-auto">
              Strategic consulting solutions for life sciences and biopharma companies, from market strategy to deal execution.
            </p>
          </div>
        </div>
      </section>

      {/* Market Intelligence and Strategy */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-display font-bold text-secondary-900 text-center mb-16">
            Market Intelligence and Strategy Consulting
          </h2>
          <div className="grid grid-cols-1 gap-12 lg:grid-cols-3">
            <div 
              className="bg-white p-8 rounded-xl border border-secondary-200 cursor-pointer hover:shadow-lg transition-shadow duration-300"
              onClick={() => setSelectedService('Market Intelligence')}
            >
              <LineChart className="h-12 w-12 text-primary-600" />
              <h3 className="mt-6 text-2xl font-display font-bold text-secondary-900">Growth Strategy</h3>
              <ul className="mt-6 space-y-3 text-secondary-600">
                <li className="flex items-center">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary-600 mr-2"></span>
                  Competitive landscape and market entry
                </li>
                <li className="flex items-center">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary-600 mr-2"></span>
                  Portfolio or Indication prioritization
                </li>
                <li className="flex items-center">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary-600 mr-2"></span>
                  Market size and commercial opportunity
                </li>
              </ul>
            </div>

            <div 
              className="bg-white p-8 rounded-xl border border-secondary-200 cursor-pointer hover:shadow-lg transition-shadow duration-300"
              onClick={() => setSelectedService('Custom Intelligence')}
            >
              <Brain className="h-12 w-12 text-primary-600" />
              <h3 className="mt-6 text-2xl font-display font-bold text-secondary-900">Custom Intelligence</h3>
              <ul className="mt-6 space-y-3 text-secondary-600">
                <li className="flex items-center">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary-600 mr-2"></span>
                  Primary and secondary market research
                </li>
                <li className="flex items-center">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary-600 mr-2"></span>
                  Technology or therapy area landscape
                </li>
                <li className="flex items-center">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary-600 mr-2"></span>
                  KOL access
                </li>
              </ul>
            </div>

            <div 
              className="bg-white p-8 rounded-xl border border-secondary-200 cursor-pointer hover:shadow-lg transition-shadow duration-300"
              onClick={() => setSelectedService('Due Diligence')}
            >
              <ShieldCheck className="h-12 w-12 text-primary-600" />
              <h3 className="mt-6 text-2xl font-display font-bold text-secondary-900">Due Diligence</h3>
              <ul className="mt-6 space-y-3 text-secondary-600">
                <li className="flex items-center">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary-600 mr-2"></span>
                  Scientific due diligence
                </li>
                <li className="flex items-center">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary-600 mr-2"></span>
                  Commercial due diligence
                </li>
                <li className="flex items-center">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary-600 mr-2"></span>
                  Technology platform diligence
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Partnering and Transactions */}
      <section className="py-20 bg-secondary-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-display font-bold text-secondary-900 text-center mb-16">
            Partnering and Transactions
          </h2>
          <div className="grid grid-cols-1 gap-12 lg:grid-cols-3">
            <div 
              className="bg-white p-8 rounded-xl border border-secondary-200 cursor-pointer hover:shadow-lg transition-shadow duration-300"
              onClick={() => setSelectedService('M&A')}
            >
              <Building2 className="h-12 w-12 text-primary-600" />
              <h3 className="mt-6 text-2xl font-display font-bold text-secondary-900">M&A</h3>
              <ul className="mt-6 space-y-3 text-secondary-600">
                <li className="flex items-center">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary-600 mr-2"></span>
                  Deal conceptualization and scouting
                </li>
                <li className="flex items-center">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary-600 mr-2"></span>
                  End-to-end transaction advisory
                </li>
                <li className="flex items-center">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary-600 mr-2"></span>
                  Valuation
                </li>
                <li className="flex items-center">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary-600 mr-2"></span>
                  Exit support
                </li>
              </ul>
            </div>

            <div 
              className="bg-white p-8 rounded-xl border border-secondary-200 cursor-pointer hover:shadow-lg transition-shadow duration-300"
              onClick={() => setSelectedService('Licensing')}
            >
              <FileSearch className="h-12 w-12 text-primary-600" />
              <h3 className="mt-6 text-2xl font-display font-bold text-secondary-900">Licensing</h3>
              <ul className="mt-6 space-y-3 text-secondary-600">
                <li className="flex items-center">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary-600 mr-2"></span>
                  In- and out-licensing
                </li>
                <li className="flex items-center">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary-600 mr-2"></span>
                  Ad hoc or full-service BD&L advisory
                </li>
                <li className="flex items-center">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary-600 mr-2"></span>
                  Asset identification and diligence
                </li>
              </ul>
            </div>

            <div 
              className="bg-white p-8 rounded-xl border border-secondary-200 cursor-pointer hover:shadow-lg transition-shadow duration-300"
              onClick={() => setSelectedService('Partnership')}
            >
              <Handshake className="h-12 w-12 text-primary-600" />
              <h3 className="mt-6 text-2xl font-display font-bold text-secondary-900">Partnership</h3>
              <ul className="mt-6 space-y-3 text-secondary-600">
                <li className="flex items-center">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary-600 mr-2"></span>
                  BD and Alliance management
                </li>
                <li className="flex items-center">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary-600 mr-2"></span>
                  Joint venture or co-development
                </li>
                <li className="flex items-center">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary-600 mr-2"></span>
                  R&D / academic collaborations
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-display font-bold text-white">
              Ready to Transform Your Business?
            </h2>
            <p className="mt-4 text-xl text-primary-100">
              Let's discuss how our expertise can help you achieve your goals.
            </p>
            <a
              href="/contact"
              className="mt-8 inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-primary-700 bg-white hover:bg-primary-50"
            >
              Contact Us
            </a>
          </div>
        </div>
      </section>

      {/* Service Modal */}
      {selectedService && serviceData[selectedService] && (
        <ServiceModal
          isOpen={true}
          onClose={() => setSelectedService(null)}
          {...serviceData[selectedService]}
        />
      )}
    </div>
  );
};

export default Services;