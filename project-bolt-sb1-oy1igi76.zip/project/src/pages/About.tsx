import React from 'react';
import { Users, Target, Award } from 'lucide-react';

const About = () => {
  return (
    <div>
      {/* Hero Section */}
      <section className="bg-primary-900 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl font-display font-bold sm:text-5xl">About Biostrateon</h1>
            <p className="mt-6 text-xl text-primary-100 max-w-3xl mx-auto">
             Biostrateon is a strategy consulting and trasnaction advisory firm dedicated to serving the life sciences and biopharma industry. 
            </p>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div>
              <h2 className="text-3xl font-display font-bold text-secondary-900">Our Mission</h2>
              <p className="mt-4 text-lg text-secondary-600">
                To accelerate innovation in life sciences by providing strategic insights and actionable solutions that drive meaningful impact for our clients. We thrive at the intersections of cutting edge technolgies in the biopharma and life sciences ecosystem. 
              </p>
            </div>
            <div>
              <h2 className="text-3xl font-display font-bold text-secondary-900">Why Us</h2>
              <p className="mt-4 text-lg text-secondary-600">
                We bring a business mindset coupled with deep scientific rigor to deliver holistic insights. In an industry where nuanced scientific distinctions shape competitive positioning, this dual perspective is essential. 
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-20 bg-secondary-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-display font-bold text-secondary-900 text-center">Our Values</h2>
          <div className="mt-16 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
            <div className="bg-white p-8 rounded-xl shadow-sm">
              <Users className="h-12 w-12 text-primary-600" />
              <h3 className="mt-6 text-xl font-semibold text-secondary-900">Enduring Relationships</h3>
              <p className="mt-4 text-secondary-600">
               We believe that long-term, trust-based relationships are the foundation of impactful consulting. We often deliver continuing insights long after our engagements are over, with an aim become true strategic partners—enabling sustained value creation over time.
              </p>
            </div>
            <div className="bg-white p-8 rounded-xl shadow-sm">
              <Target className="h-12 w-12 text-primary-600" />
              <h3 className="mt-6 text-xl font-semibold text-secondary-900">Excellence & Clarity</h3>
              <p className="mt-4 text-secondary-600">
                We maintain the highest standards of quality in our work, delivering exceptional results into clear, decision-oriented insights that align scientific potential with business priorities.
              </p>
            </div>
            <div className="bg-white p-8 rounded-xl shadow-sm">
              <Award className="h-12 w-12 text-primary-600" />
              <h3 className="mt-6 text-xl font-semibold text-secondary-900">Global Reach and Persepective </h3>
              <p className="mt-4 text-secondary-600">
               With experience across geographies and sectors, we bring a broad, informed view that helps clients anticipate trends and act confidently in a globalized market.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Leadership Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-display font-bold text-secondary-900">Our Leadership</h2>
            <p className="mt-4 text-xl text-secondary-500">
              Experienced leadership driving innovation in life sciences
            </p>
          </div>
          <div className="mt-16 max-w-3xl mx-auto">
            <div className="text-center">
              <div className="relative w-64 h-64 mx-auto">
                <img
                  src="https://imgur.com/a/CzQoIFc"
                  alt="Amandeep Singh"
                  className="rounded-full object-cover w-full h-full"
                />
              </div>
              <h3 className="mt-6 text-2xl font-semibold text-secondary-900">Amandeep Singh</h3>
              <p className="text-lg text-primary-600">Founder & CEO</p>
              <div className="mt-6 text-left text-secondary-600 space-y-4">
                <p>
                  Amandeep brings over a decade of experience in life sciences across strategy advisory and investment banking industry, and experience in early-phase drug discovery. He has been part of several successful deals including M&A, licensing and fundraising, with cumulative deal value of up to $400M, and has led several strategy projects across various domains. He brings deep expertise and network in biopharma outsourced services, precision medicine and AI platforms for life sciences.
                </p>
                <p>
                  He is passionate about emerging technologies at the forefront of biopharma R&D and enjoys to bridge the gap between start-ups and multinationals. Prior to starting Biostrateon, Amandeep worked at Mehta Partners/MP Advisors, a biopharma only strategy and financial advisory firm. Previously he has worked at IniXium (now Sygnature discovery) and Siemens Healthineers. He obtained his PhD in Biophysics from Indian Institute of Science, Bangalore.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;