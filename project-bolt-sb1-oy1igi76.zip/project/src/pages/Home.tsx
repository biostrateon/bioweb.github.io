import React from 'react';
import { ArrowRight, LineChart, Brain, ShieldCheck, Building2, FileSearch, HeartHandshake } from 'lucide-react';
import { Link } from 'react-router-dom';
import { articles } from './Insights';

const Home = () => {
  const latestArticles = articles.slice(0, 3);

  return (
    <div>
      {/* Hero Section */}
      <section className="relative bg-primary-900 text-white">
        <div className="absolute inset-0 bg-[url('https://www.pexels.com/photo/close-up-of-abstract-shapes-25626515/')] bg-cover bg-center">
          <div className="absolute inset-0 bg-primary-900/90 mix-blend-multiply" />
        </div>
        <div className="relative">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32">
            <div className="lg:grid lg:grid-cols-12 lg:gap-8">
              <div className="lg:col-span-7">
                <h1 className="text-4xl font-display font-bold tracking-tight sm:text-5xl md:text-6xl">
                  Strategic Solutions for Life Sciences
                </h1>
                <p className="mt-6 text-xl text-primary-100">
                  Empowering biopharma and life sciences leaders with data-driven insights and strategic consulting to accelerate innovation and drive growth.
                </p>
                <div className="mt-10 flex items-center gap-x-6">
                  <Link
                    to="/contact"
                    className="rounded-md bg-primary-500 px-6 py-3 text-lg font-semibold text-white shadow-sm hover:bg-primary-400 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary-500"
                  >
                    Get Started
                  </Link>
                  <Link
                    to="/services"
                    className="text-lg font-semibold leading-6 text-white flex items-center group"
                  >
                    Learn more <ArrowRight className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1" />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-display font-bold text-secondary-900">Our Services</h2>
            <p className="mt-4 text-xl text-secondary-500">
              Comprehensive consulting solutions for the life sciences industry
            </p>
          </div>

          <div className="mt-20">
            {/* Market Intelligence and Strategy */}
            <div className="mb-16">
              <h3 className="text-2xl font-display font-bold text-secondary-900 mb-8">Market Intelligence and Strategy Consulting</h3>
              <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
                <Link to="/services" className="group relative p-8 bg-white border border-secondary-200 rounded-2xl shadow-sm hover:shadow-md transition-shadow">
                  <div className="absolute top-8 left-8">
                    <LineChart className="h-8 w-8 text-primary-600" />
                  </div>
                  <div className="pt-16">
                    <h4 className="text-xl font-semibold text-secondary-900 group-hover:text-primary-600">Growth Strategy</h4>
                    <p className="mt-4 text-secondary-500">Market entry, portfolio optimization, and commercial assessment.</p>
                  </div>
                </Link>

                <Link to="/services" className="group relative p-8 bg-white border border-secondary-200 rounded-2xl shadow-sm hover:shadow-md transition-shadow">
                  <div className="absolute top-8 left-8">
                    <Brain className="h-8 w-8 text-primary-600" />
                  </div>
                  <div className="pt-16">
                    <h4 className="text-xl font-semibold text-secondary-900 group-hover:text-primary-600">Custom Intelligence</h4>
                    <p className="mt-4 text-secondary-500">Primary research, technology landscape analysis, and KOL insights.</p>
                  </div>
                </Link>

                <Link to="/services" className="group relative p-8 bg-white border border-secondary-200 rounded-2xl shadow-sm hover:shadow-md transition-shadow">
                  <div className="absolute top-8 left-8">
                    <ShieldCheck className="h-8 w-8 text-primary-600" />
                  </div>
                  <div className="pt-16">
                    <h4 className="text-xl font-semibold text-secondary-900 group-hover:text-primary-600">Due Diligence</h4>
                    <p className="mt-4 text-secondary-500">Technical and commercial due diligence for assets and technologies.</p>
                  </div>
                </Link>
              </div>
            </div>

            {/* Partnering and Transactions */}
            <div>
              <h3 className="text-2xl font-display font-bold text-secondary-900 mb-8">Partnering and Transactions</h3>
              <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
                <Link to="/services" className="group relative p-8 bg-white border border-secondary-200 rounded-2xl shadow-sm hover:shadow-md transition-shadow">
                  <div className="absolute top-8 left-8">
                    <Building2 className="h-8 w-8 text-primary-600" />
                  </div>
                  <div className="pt-16">
                    <h4 className="text-xl font-semibold text-secondary-900 group-hover:text-primary-600">M&A</h4>
                    <p className="mt-4 text-secondary-500">End-to-end transaction advisory and deal execution support.</p>
                  </div>
                </Link>

                <Link to="/services" className="group relative p-8 bg-white border border-secondary-200 rounded-2xl shadow-sm hover:shadow-md transition-shadow">
                  <div className="absolute top-8 left-8">
                    <FileSearch className="h-8 w-8 text-primary-600" />
                  </div>
                  <div className="pt-16">
                    <h4 className="text-xl font-semibold text-secondary-900 group-hover:text-primary-600">Licensing</h4>
                    <p className="mt-4 text-secondary-500">In- and out-licensing support and BD&L advisory services.</p>
                  </div>
                </Link>

                <Link to="/services" className="group relative p-8 bg-white border border-secondary-200 rounded-2xl shadow-sm hover:shadow-md transition-shadow">
                  <div className="absolute top-8 left-8">
                    <HeartHandshake className="h-8 w-8 text-primary-600" />
                  </div>
                  <div className="pt-16">
                    <h4 className="text-xl font-semibold text-secondary-900 group-hover:text-primary-600">Partnership</h4>
                    <p className="mt-4 text-secondary-500">Strategic alliance management and collaboration frameworks.</p>
                  </div>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Latest Insights Section */}
      <section className="py-24 bg-secondary-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-display font-bold text-secondary-900">Latest Insights</h2>
            <p className="mt-4 text-xl text-secondary-500">
              Expert perspectives on industry trends and strategic developments
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {latestArticles.map((article) => (
              <Link
                to={`/insights/${article.id}`}
                key={article.id}
                className="bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-md transition-shadow duration-300"
              >
                <img
                  src={article.image}
                  alt={article.title}
                  className="h-48 w-full object-cover"
                />
                <div className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-sm font-medium text-primary-600 capitalize">
                      {article.type.replace('-', ' ')}
                    </span>
                    <span className="text-sm text-secondary-500">
                      {new Date(article.date).toLocaleDateString('en-US', {
                        month: 'long',
                        day: 'numeric',
                        year: 'numeric'
                      })}
                    </span>
                  </div>
                  <h3 className="text-xl font-semibold text-secondary-900 mb-2">
                    {article.title}
                  </h3>
                  <p className="text-secondary-600">
                    {article.description}
                  </p>
                  <div className="mt-4">
                    <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-secondary-100 text-secondary-800">
                      {article.category}
                    </span>
                  </div>
                </div>
              </Link>
            ))}
          </div>

          <div className="text-center mt-12">
            <Link
              to="/insights"
              className="inline-flex items-center text-primary-600 hover:text-primary-700"
            >
              View all insights <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-display font-bold text-white">
              Ready to Transform Your Business?
            </h2>
            <p className="mt-4 text-xl text-primary-100">
              Let's discuss how our expertise can help you achieve your goals.
            </p>
            <Link
              to="/contact"
              className="mt-8 inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-primary-700 bg-white hover:bg-primary-50"
            >
              Contact Us
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;