import React from 'react';
import { X, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { articles } from '../pages/Insights';

interface CaseStudy {
  title: string;
  description: string;
  tags: string[];
}

interface ServiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  description: string;
  bulletPoints: string[];
  caseStudies: CaseStudy[];
}

const ServiceModal = ({ isOpen, onClose, title, description, bulletPoints, caseStudies }: ServiceModalProps) => {
  if (!isOpen) return null;

  // Find related articles based on tags
  const findRelatedArticles = (tags: string[]) => {
    return articles.filter(article => 
      tags.some(tag => 
        article.category.toLowerCase() === tag.toLowerCase() ||
        article.title.toLowerCase().includes(tag.toLowerCase())
      )
    );
  };

  // Find the most relevant case study article with improved matching
  const findCaseStudyArticle = (study: CaseStudy) => {
    return articles.find(article => 
      (article.type === 'case-study' || article.category === 'Case Study') && 
      (
        article.title.toLowerCase().includes(study.title.toLowerCase()) ||
        study.title.toLowerCase().includes(article.title.toLowerCase()) ||
        study.tags.some(tag => 
          article.title.toLowerCase().includes(tag.toLowerCase()) ||
          (article.tags && article.tags.some(articleTag => 
            articleTag.toLowerCase() === tag.toLowerCase()
          ))
        )
      )
    );
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-secondary-200 p-4 flex justify-between items-center">
          <h3 className="text-2xl font-display font-bold text-secondary-900">{title}</h3>
          <button
            onClick={onClose}
            className="p-2 hover:bg-secondary-100 rounded-full"
          >
            <X className="h-6 w-6 text-secondary-500" />
          </button>
        </div>
        
        <div className="p-6">
          <p className="text-lg text-secondary-600 mb-6">{description}</p>
          
          <h4 className="text-xl font-semibold text-secondary-900 mb-4">Key Services</h4>
          <ul className="space-y-3 mb-8">
            {bulletPoints.map((point, index) => (
              <li key={index} className="flex items-center text-secondary-600">
                <span className="h-2 w-2 rounded-full bg-primary-600 mr-3"></span>
                {point}
              </li>
            ))}
          </ul>

          <h4 className="text-xl font-semibold text-secondary-900 mb-4">Case Studies & Related Content</h4>
          <div className="space-y-6">
            {caseStudies.map((study, index) => {
              const relatedArticles = findRelatedArticles(study.tags);
              const caseStudyArticle = findCaseStudyArticle(study);
              
              return (
                <div key={index} className="bg-secondary-50 rounded-lg p-4">
                  {caseStudyArticle ? (
                    <Link 
                      to={`/insights/${caseStudyArticle.id}`}
                      onClick={onClose}
                      className="block group cursor-pointer"
                    >
                      <h5 className="font-semibold text-secondary-900 mb-2 group-hover:text-primary-600 flex items-center">
                        {study.title}
                        <ArrowRight className="ml-2 h-4 w-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                      </h5>
                      <p className="text-secondary-600 mb-3">{study.description}</p>
                    </Link>
                  ) : (
                    <div className="cursor-default">
                      <h5 className="font-semibold text-secondary-900 mb-2">{study.title}</h5>
                      <p className="text-secondary-600 mb-3">{study.description}</p>
                    </div>
                  )}
                  
                  <div className="flex flex-wrap gap-2 mb-4">
                    {study.tags.map((tag, tagIndex) => (
                      <span
                        key={tagIndex}
                        className="px-3 py-1 bg-primary-100 text-primary-700 rounded-full text-sm"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>

                  {relatedArticles.length > 0 && (
                    <div className="mt-4 border-t border-secondary-200 pt-4">
                      <h6 className="text-sm font-semibold text-secondary-900 mb-2">Related Insights</h6>
                      <div className="space-y-2">
                        {relatedArticles.map(article => (
                          <Link
                            key={article.id}
                            to={`/insights/${article.id}`}
                            onClick={onClose}
                            className="flex items-center justify-between p-2 rounded-lg hover:bg-secondary-100 group"
                          >
                            <span className="text-secondary-600 group-hover:text-secondary-900">
                              {article.title}
                            </span>
                            <ArrowRight className="h-4 w-4 text-secondary-400 group-hover:text-primary-600" />
                          </Link>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ServiceModal;