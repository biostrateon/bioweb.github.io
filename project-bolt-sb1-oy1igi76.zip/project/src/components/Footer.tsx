import React from 'react';
import { Link } from 'react-router-dom';
import { Linkedin, Twitter } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-secondary-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1">
            <div className="flex items-center">
              <img src="/biostrateon-logo-white.png" alt="Biostrateon" className="h-8" />
            </div>
            <p className="mt-4 text-secondary-300">
              Shaping business strategies to unlock transformational growth
            </p>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider">Company</h3>
            <ul className="mt-4 space-y-2">
              <li><Link to="/about" className="text-secondary-300 hover:text-white">About</Link></li>
              <li><Link to="/services" className="text-secondary-300 hover:text-white">Services</Link></li>
              <li><Link to="/insights" className="text-secondary-300 hover:text-white">Insights</Link></li>
              <li><Link to="/contact" className="text-secondary-300 hover:text-white">Contact</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider">Services</h3>
            <ul className="mt-4 space-y-2">
              <li><Link to="/services" className="text-secondary-300 hover:text-white">Market Intelligence</Link></li>
              <li><Link to="/services" className="text-secondary-300 hover:text-white">Due Diligence</Link></li>
              <li><Link to="/services" className="text-secondary-300 hover:text-white">M&A Advisory</Link></li>
              <li><Link to="/services" className="text-secondary-300 hover:text-white">Licensing Support</Link></li>
              <li><Link to="/services" className="text-secondary-300 hover:text-white">Strategic Partnerships</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider">Connect</h3>
            <div className="mt-4 flex space-x-4">
              <a href="#" className="text-secondary-300 hover:text-white">
                <Linkedin className="h-6 w-6" />
              </a>
              <a href="#" className="text-secondary-300 hover:text-white">
                <Twitter className="h-6 w-6" />
              </a>
            </div>
          </div>
        </div>
        
        <div className="mt-12 border-t border-secondary-700 pt-8">
          <p className="text-center text-secondary-300">
            © {new Date().getFullYear()} Biostrateon. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;